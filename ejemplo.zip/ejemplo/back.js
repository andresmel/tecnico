

var usu;
var contra;

function guardar(){
	usu=document.getElementById('nom').value;
	contra=document.getElementById('con').value;
if(usu=="" || contra==""){
alert("Datos Obligatorios *");

return false;
}
else{
enviar();

}



}