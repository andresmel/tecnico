 var resp;
function enviar() {
  var nomb= usu;
  var contr = contra;
  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
	  
      document.getElementById("dd").innerHTML = this.responseText;
	  resp=this.responseText;
	  setTimeout ("ir()", 1000);
          
    }

  }
  xmlhttp.open("GET", "../ejemplo/back/servidor.php?usuario=" + nomb + "&contrasena=" + contr, true);
  xmlhttp.send();

}
function ir(){
	if(resp=="ok"){
	location.href ="http://text2.html";
	}
}