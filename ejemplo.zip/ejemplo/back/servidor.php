<?php
$nombre="amelopachon@uniminuto.edu.co";
$contrase="1236789";
  if(isset($_GET['usuario'])){
	if($_GET['usuario']==$nombre && $_GET['contrasena']==$contrase){
		echo "ok";
		json_encode("ok");
	}
	else{
	echo "error";
	json_encode("error");
	}
  }
?>